package genericsexercises;

public interface StudentInt<T, U> {
	void displayStd(T i, U x);
}
