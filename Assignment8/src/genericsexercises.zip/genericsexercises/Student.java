package genericsexercises;

public class Student<T, U> {
	
	public Student(T i, U m) {
		
	}
	
}
