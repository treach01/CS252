package question2;

public interface File {
	public String filename();
	public void content();
}
