package question2;

public interface Memory {
	public int size();
}
