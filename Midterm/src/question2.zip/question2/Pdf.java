package question2;

public class Pdf extends Document {
	
}
